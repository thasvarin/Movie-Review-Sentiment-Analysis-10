import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


public class Main {


   

    public static Scanner sc;
    public static void main(String[] args) throws IOException {


        HashTable hashTable = new HashTable();
        BufferedReader br = new BufferedReader(new FileReader("MR.txt"));


        for (String line; (line = br.readLine()) != null; ) {
            int index = 2;
            int lastIndex = 2;
            int score = Character.getNumericValue(line.charAt(0));

            String[] word = line.split(" ");

            for (int i = 0; i < word.length; i++) {
                hashTable.put(word[i], score);
            }
        }
        //hashTable.printAll();
        hashTable.printAverageAll();
        //-----------------------------------------------------------------------------
        int x = 1;
        while(x != 0) {
            HashTable newHash = new HashTable();
            sc = new Scanner(System.in);


            System.out.print("Enter your comment : ");
            String lineInput = sc.nextLine();
                                                            
            String[] line = lineInput.split(" ");


            for (String a : line) {
                newHash.put(a, hashTable.getAverage(a));
            }
            newHash.printAll();
            newHash.printAverageAll();
            System.out.println();
            System.out.print("If do it again entry \"1\" , but if you want to end this program entry \"0\" : ");
            x = sc.nextInt();
        }
    }
}





