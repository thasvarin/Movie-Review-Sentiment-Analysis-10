

/**
 * Created by 1 on 4/18/2017.
 */
public class WordEntry {

    private String word;
    private double numAppearance;
    private double score;
    private double totalScore;


    public WordEntry(String word, double score) {
        this.word = word;
        this.score=score;
        this.totalScore+=score;
        this.numAppearance = 1;

    }

    public void addNewAppearance(double score){
        this.score = score;
        this.totalScore+=score;
        ++this.numAppearance ;

    }

    public double getScore(){return score;}

    public String getWord() {
        return this.word;
    }

    public double getAverange(){
       return totalScore/numAppearance;
    }


}
